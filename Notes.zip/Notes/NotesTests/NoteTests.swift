//
//  NoteTests.swift
//  NotesTests
//
//  Created by Денис Домашевич on 2/3/20.
//  Copyright © 2020 Денис Домашевич. All rights reserved.
//

import XCTest
@testable import Notes

class NoteTests: XCTestCase {
    
    override func setUp() {
        
    }
    
}

