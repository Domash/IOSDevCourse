//
//  BaseBackendOperation.swift
//  Notes
//
//  Created by Денис Домашевич on 2/26/20.
//  Copyright © 2020 Денис Домашевич. All rights reserved.
//

import Foundation

class BaseBackendOperation: AsyncOperation {
    override init() {
        super.init()
    }
}
