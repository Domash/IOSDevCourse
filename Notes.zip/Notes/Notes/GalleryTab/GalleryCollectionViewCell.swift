//
//  GalleryCollectionViewCell.swift
//  Notes
//
//  Created by Денис Домашевич on 2/25/20.
//  Copyright © 2020 Денис Домашевич. All rights reserved.
//

import UIKit

class GalleryCollectionViewCell: UICollectionViewCell {

    
    @IBOutlet weak var imageView: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

}
